
def lambda_handler(event, context):
    message = 'Hello'  
    return { 
        'message' : message
    }